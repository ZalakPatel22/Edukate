<?php
session_start();
include_once 'security.php';
if (isset($_SESSION['admin_user'])) {
  log_admin_event('Admin logged out: ' . $_SESSION['admin_user'], 'info');
  $_SESSION = [];
  if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
  }
  session_destroy();
}
header('Location: index.php');
exit;
