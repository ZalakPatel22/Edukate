<?php
session_start();
include_once 'security.php';
if (!isset($_SESSION['admin_user'])) {
  header('Location: index.php');
  exit;
}

$settings = load_security_settings();
$loginHistory = load_login_history(20);
$activityLogs = load_activity_logs(20);
$message = '';
$messageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['action']) && $_POST['action'] === 'force_logout') {
    log_admin_event('Admin forced session logout from security settings', 'warning');
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
      $params = session_get_cookie_params();
      setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    header('Location: index.php?timeout=1');
    exit;
  }

  $settings['login_history_enabled'] = isset($_POST['login_history_enabled']);
  $settings['captcha_enabled'] = isset($_POST['captcha_enabled']);
  $settings['otp_enabled'] = isset($_POST['otp_enabled']);
  $settings['activity_logs_enabled'] = isset($_POST['activity_logs_enabled']);
  $settings['session_timeout'] = max(5, intval($_POST['session_timeout'] ?? 30));

  save_security_settings($settings);
  log_admin_event('Security settings updated', 'success');
  $message = 'Security management settings were updated successfully.';
  $messageType = 'success';
  $loginHistory = load_login_history(20);
  $activityLogs = load_activity_logs(20);
}
?>
<?php include('header.php'); ?>

<?php if (!empty($message)) : ?>
  <div class="admin-alert <?= $messageType === 'success' ? 'success' : 'error' ?>">
    <?= htmlspecialchars($message) ?>
  </div>
<?php endif; ?>

<div class="row admin-grid-2">
  <div>
    <div class="admin-panel">
      <div class="admin-panel-head">
        <div>
          <h3>Security Management</h3>
          <p>Enable and configure login protections, session controls, and auditing.</p>
        </div>
      </div>
      <form method="post">
        <div class="form-group">
          <label class="security-label">
            <input type="checkbox" name="login_history_enabled" <?= $settings['login_history_enabled'] ? 'checked' : '' ?>>
            Enable login history
          </label>
        </div>
        <div class="form-group">
          <label class="security-label">
            <input type="checkbox" name="captcha_enabled" <?= $settings['captcha_enabled'] ? 'checked' : '' ?>>
            Enable CAPTCHA on admin login
          </label>
        </div>
        <div class="form-group">
          <label class="security-label">
            <input type="checkbox" name="otp_enabled" <?= $settings['otp_enabled'] ? 'checked' : '' ?>>
            Enable OTP verification
          </label>
        </div>
        <div class="form-group">
          <label class="security-label" for="session_timeout">Session timeout (minutes)</label>
          <input type="number" id="session_timeout" name="session_timeout" class="form-control" min="5" value="<?= htmlspecialchars($settings['session_timeout']) ?>">
        </div>
        <div class="form-group">
          <label class="security-label">
            <input type="checkbox" name="activity_logs_enabled" <?= $settings['activity_logs_enabled'] ? 'checked' : '' ?>>
            Enable activity logs
          </label>
        </div>
        <button type="submit" class="admin-btn">Save security settings</button>
      </form>
    </div>
  </div>

  <div>
    <div class="admin-panel">
      <div class="admin-panel-head">
        <div>
          <h3>Active Session</h3>
          <p>Manage current session behavior and force logout if needed.</p>
        </div>
      </div>
      <div class="admin-list">
        <li>
          <span>Current admin</span>
          <span><?= htmlspecialchars($_SESSION['admin_user']) ?></span>
        </li>
        <li>
          <span>Session timeout</span>
          <span><?= htmlspecialchars($settings['session_timeout']) ?> minutes</span>
        </li>
        <li>
          <span>CAPTCHA enabled</span>
          <span class="status-pill <?= $settings['captcha_enabled'] ? 'success' : '' ?>"><?= $settings['captcha_enabled'] ? 'On' : 'Off' ?></span>
        </li>
        <li>
          <span>OTP verification</span>
          <span class="status-pill <?= $settings['otp_enabled'] ? 'success' : '' ?>"><?= $settings['otp_enabled'] ? 'On' : 'Off' ?></span>
        </li>
      </div>
      <form method="post" style="margin-top: 16px;">
        <input type="hidden" name="action" value="force_logout">
        <button type="submit" class="admin-btn">Force logout</button>
      </form>
    </div>
  </div>
</div>

<div class="row admin-grid-2">
  <div>
    <div class="admin-panel">
      <div class="admin-panel-head">
        <div>
          <h3>Login History</h3>
          <p>Recent admin login attempts and authentication results.</p>
        </div>
      </div>
      <table class="security-table">
        <thead>
          <tr>
            <th>Time</th>
            <th>User</th>
            <th>Status</th>
            <th>IP</th>
            <th>Reason</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($loginHistory)) : ?>
            <tr><td colspan="5">No login activity available yet.</td></tr>
          <?php else : ?>
            <?php foreach ($loginHistory as $entry) : ?>
              <tr>
                <td><?= htmlspecialchars($entry['timestamp'] ?? '') ?></td>
                <td><?= htmlspecialchars($entry['username'] ?? 'unknown') ?></td>
                <td><span class="status-pill <?= !empty($entry['success']) ? 'success' : 'pending' ?>"><?= !empty($entry['success']) ? 'Success' : 'Failed' ?></span></td>
                <td><?= htmlspecialchars($entry['ip'] ?? '') ?></td>
                <td><?= htmlspecialchars($entry['reason'] ?? '') ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div>
    <div class="admin-panel">
      <div class="admin-panel-head">
        <div>
          <h3>Activity Logs</h3>
          <p>Recent security events and admin changes.</p>
        </div>
      </div>
      <table class="security-table">
        <thead>
          <tr>
            <th>Time</th>
            <th>Event</th>
            <th>User</th>
            <th>Type</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($activityLogs)) : ?>
            <tr><td colspan="4">No activity logs available.</td></tr>
          <?php else : ?>
            <?php foreach ($activityLogs as $entry) : ?>
              <tr>
                <td><?= htmlspecialchars($entry['timestamp'] ?? '') ?></td>
                <td><?= htmlspecialchars($entry['message'] ?? '') ?></td>
                <td><?= htmlspecialchars($entry['user'] ?? 'system') ?></td>
                <td><?= htmlspecialchars(ucwords($entry['type'] ?? 'info')) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include('footer.php'); ?>