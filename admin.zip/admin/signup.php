<?php
session_start();
require_once __DIR__ . '/security.php';

$message = '';
$messageType = 'success';

if (isset($_SESSION['admin_user'])) {
  header('Location: dashboard.php');
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = trim($_POST['username'] ?? '');
  $password = trim($_POST['password'] ?? '');
  $confirmPassword = trim($_POST['confirm_password'] ?? '');

  if ($username === '' || $password === '' || $confirmPassword === '') {
    $message = 'Please fill in all fields.';
    $messageType = 'error';
  } elseif ($password !== $confirmPassword) {
    $message = 'Passwords do not match.';
    $messageType = 'error';
  } else {
    save_admin_account([
      'username' => $username,
      'password' => $password,
    ]);
    $_SESSION['admin_auth_message'] = 'Admin account created successfully. Please sign in.';
    $_SESSION['admin_auth_message_type'] = 'success';
    header('Location: index.php');
    exit;
  }
}
?>

<?php include('header.php'); ?>

<?php if (!empty($message)) : ?>
  <div class="admin-alert <?= $messageType === 'success' ? 'success' : 'error' ?>">
    <?= htmlspecialchars($message) ?>
  </div>
<?php endif; ?>

<div class="row justify-content-center">
  <div class="col-lg-5 col-md-7">
    <div class="admin-card">
      <h2>Admin Sign Up</h2>
      <p>Create a new admin account for the Edukate panel.</p>
      <form method="post">
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" class="form-control" placeholder="Admin username" required>
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" class="form-control" placeholder="Admin password" required>
        </div>
        <div class="form-group">
          <label for="confirm_password">Confirm Password</label>
          <input type="password" id="confirm_password" name="confirm_password" class="form-control" placeholder="Confirm password" required>
        </div>
        <button type="submit" class="auth-btn">Create Account</button>
      </form>
      <div class="auth-footer">
        <p>Already have an admin account? <a href="index.php" class="auth-link">Sign in</a></p>
      </div>
    </div>
  </div>
</div>

<?php include('footer.php'); ?>