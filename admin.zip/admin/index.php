<?php
session_start();
require_once __DIR__ . '/security.php';

$message = '';
$messageType = 'success';
$settings = load_security_settings();
$captchaQuestion = '';
$otpStep = is_otp_step();
$otpCode = '';

if (isset($_SESSION['admin_auth_message'])) {
  $message = $_SESSION['admin_auth_message'];
  $messageType = $_SESSION['admin_auth_message_type'] ?? 'success';
  unset($_SESSION['admin_auth_message'], $_SESSION['admin_auth_message_type']);
}

if (isset($_SESSION['admin_user'])) {
  header('Location: dashboard.php');
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['otp_code'])) {
    $otpCode = trim($_POST['otp_code']);
    if (validate_otp_code($otpCode) && isset($_SESSION['otp_stage_user'])) {
      $username = $_SESSION['otp_stage_user'];
      session_regenerate_id(true);
      $_SESSION['admin_user'] = $username;
      $_SESSION['last_activity'] = time();
      log_login_attempt($username, true, 'OTP verified');
      log_admin_event('Admin logged in with OTP: ' . $username, 'success');
      clear_otp_state();
      header('Location: dashboard.php');
      exit;
    }
    $message = 'Invalid or expired OTP code. Please try again.';
    $messageType = 'error';
    $otpStep = true;
  } else {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $captchaAnswer = trim($_POST['captcha_answer'] ?? '');

    if ($username === '' || $password === '') {
      $message = 'Please enter both admin username and password.';
      $messageType = 'error';
    } elseif ($settings['captcha_enabled'] && !validate_captcha_answer($captchaAnswer)) {
      $message = 'CAPTCHA response is incorrect. Please try again.';
      $messageType = 'error';
      $captchaQuestion = generate_captcha_question();
    } else {
      $adminAccount = load_admin_account();
      $validAdmin = false;
      if (!empty($adminAccount)) {
        $validAdmin = $username === ($adminAccount['username'] ?? '') && $password === ($adminAccount['password'] ?? '');
      }
      if (!$validAdmin) {
        $validAdmin = $username === 'admin' && $password === 'admin123';
      }
      if (!$validAdmin) {
        $message = 'Invalid admin credentials.';
        $messageType = 'error';
        log_login_attempt($username, false, 'Invalid credentials');
      } else {
        if ($settings['otp_enabled']) {
          $_SESSION['otp_stage_user'] = $username;
          $otpCode = generate_otp_code();
          $otpStep = true;
          log_login_attempt($username, false, 'OTP required');
          log_admin_event('OTP generated for admin login attempt: ' . $username, 'info');
          $message = 'OTP verification is enabled. Enter the code below.';
          $messageType = 'success';
        } else {
          session_regenerate_id(true);
          $_SESSION['admin_user'] = $username;
          $_SESSION['last_activity'] = time();
          log_login_attempt($username, true, 'Login successful');
          log_admin_event('Admin logged in: ' . $username, 'success');
          header('Location: dashboard.php');
          exit;
        }
      }
    }
  }
}

if (!$otpStep && $settings['captcha_enabled']) {
  $captchaQuestion = generate_captcha_question();
}
?>
<?php include('header.php'); ?>

<?php if (!empty($message)) : ?>
  <div class="admin-alert <?= $messageType === 'success' ? 'success' : 'error' ?>">
    <?= htmlspecialchars($message) ?>
  </div>
<?php endif; ?>

<div class="row justify-content-center">
  <div class="col-lg-5 col-md-7">
    <div class="admin-card">
      <?php if ($otpStep) : ?>
        <h2>OTP Verification</h2>
        <p>Enter the one-time password sent for the admin login attempt.</p>
        <form method="post">
          <div class="form-group">
            <label for="otp_code">OTP Code</label>
            <input type="text" id="otp_code" name="otp_code" class="form-control" placeholder="Enter OTP code" required>
          </div>
          <button type="submit" class="auth-btn">Verify OTP</button>
        </form>
        <?php if (!empty($otpCode)) : ?>
          <div class="auth-footer">
            <p><strong>Demo OTP:</strong> <?= htmlspecialchars($otpCode) ?></p>
          </div>
        <?php endif; ?>
      <?php else : ?>
        <h2>Admin Login</h2>
        <p>Enter your admin credentials to manage the Edukate site.</p>
        <form method="post">
          <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" class="form-control" placeholder="Admin username" required>
          </div>
          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" class="form-control" placeholder="Admin password" required>
          </div>
          <?php if ($settings['captcha_enabled']) : ?>
            <div class="form-group">
              <label for="captcha_answer">CAPTCHA: <?= htmlspecialchars($captchaQuestion) ?></label>
              <input type="text" id="captcha_answer" name="captcha_answer" class="form-control" placeholder="Enter CAPTCHA answer" required>
            </div>
          <?php endif; ?>
          <button type="submit" class="auth-btn">Sign In</button>
        </form>
        <div class="auth-footer">
          <p>Don't have an admin account? <a href="signup.php" class="auth-link">Create one</a></p>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include('footer.php'); ?>
